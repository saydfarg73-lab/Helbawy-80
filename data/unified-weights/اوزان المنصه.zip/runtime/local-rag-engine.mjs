// HELBAWEY LOCAL RAG ENGINE (100% Offline, Zero External APIs)
import fs from 'node:fs';
import path from 'node:path';

export function normalizeArabicEnglish(input) {
  return String(input || '')
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function tokenize(input) {
  const norm = normalizeArabicEnglish(input);
  if (!norm) return [];
  const stop = new Set(['في','من','على','الى','عن','مع','هذا','هذه','و','او','the','is','and','or','in','of','to']);
  return norm.split(' ').filter((t) => t.length >= 2 && !stop.has(t));
}

export function loadKnowledgeIndex(indexPath) {
  const resolved = path.resolve(indexPath);
  if (!fs.existsSync(resolved)) {
    return { vocabulary: [], idf: {}, chunks: [] };
  }
  return JSON.parse(fs.readFileSync(resolved, 'utf8'));
}

export function searchLocalKnowledge(index, query, topK = 4) {
  const tokens = tokenize(query);
  if (!tokens.length || !index.chunks?.length) return [];
  const qCounts = {};
  for (const t of tokens) qCounts[t] = (qCounts[t] || 0) + 1;
  const qVec = {};
  let qNormSq = 0;
  for (const [t, c] of Object.entries(qCounts)) {
    const w = (c / tokens.length) * (index.idf?.[t] || 1);
    qVec[t] = w;
    qNormSq += w * w;
  }
  const qNorm = Math.sqrt(qNormSq) || 1;
  const hits = [];
  for (const chunk of index.chunks) {
    let dot = 0;
    let dNormSq = 0;
    for (const v of Object.values(chunk.tf || {})) dNormSq += v * v;
    for (const [t, qw] of Object.entries(qVec)) {
      if (chunk.tf?.[t]) dot += qw * chunk.tf[t];
    }
    const score = dot / (qNorm * (Math.sqrt(dNormSq) || 1));
    if (score > 0.01) {
      hits.push({ docId: chunk.docId, title: chunk.title, chunkIndex: chunk.chunkIndex, excerpt: chunk.text, score: Number(score.toFixed(4)) });
    }
  }
  return hits.sort((a, b) => b.score - a.score).slice(0, topK);
}
