# QLoRA Offline Fine-Tuning Pipeline (ALHELBAWEY)
python train_qlora.py --base_model Qwen2.5-1.5B-Instruct --dataset ./dataset.jsonl --r 16 --epochs 3 --lr 2e-4 --output ./adapters/company-contracts